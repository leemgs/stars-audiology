# HEAR-WORK AI: Occupational Stress, Tinnitus, and Hearing Outcomes

This repository contains an American Journal of Audiology-targeted manuscript package and reproducible starter code for public-data analyses.

## Repository structure

```text
./README.md
./paper/   LaTeX manuscript, bibliography, tables, and compiled PDF
./code/    Reproducible analysis starter code for KNHANES/NHANES and MedGemma-assisted variable extraction
./ppt/     Sharing deck for collaborators and clinicians
```

## Primary public datasets selected

1. **KNHANES** is the primary development dataset because it is Korean, population-based, and has supported prior tinnitus and hearing-loss epidemiology using audiometry and health questionnaire data.
2. **NHANES** is the geographic external validation dataset because it provides public audiometry, noise-exposure, tinnitus/hearing questionnaires, and rich demographic and health covariates.

The manuscript treats occupational stress as an exposure associated with tinnitus/hearing outcomes, not as a proven direct cause.

## Build the manuscript

```bash
cd paper
bash build.sh
```

## Run the code starter

```bash
cd code
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python src/run_pipeline.py --config config/study_config.yaml
```

The code is intentionally written as a reproducible scaffold. It does not redistribute restricted KNHANES files. Download KNHANES through the official KDCA portal and place files under `code/data/raw/knhanes/`. NHANES public files can be downloaded directly by the scripts where URLs are configured.

## Ethics and safety

This package does not provide medical diagnosis or treatment advice. AI outputs are restricted to research feature extraction, risk stratification, and guideline-linked explanation templates. All clinical decisions must remain with licensed clinicians.
